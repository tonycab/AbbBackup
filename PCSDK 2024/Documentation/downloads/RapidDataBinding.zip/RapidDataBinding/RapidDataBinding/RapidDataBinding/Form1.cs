﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ABB.Robotics;
using ABB.Robotics.Controllers;
using ABB.Robotics.Controllers.RapidDomain;
using ABB.Robotics.Controllers.MotionDomain;
using ABB.Robotics.Controllers.ConfigurationDomain;
using ABB.Robotics.Controllers.Discovery;

namespace RapidDataBinding
{
    public partial class Form1 : Form
    {
        ABB.Robotics.Controllers.Controller objController;
        private NetworkScanner objNetworkWatcher = null;
        RapidData data1;
        RapidData data2;
        RapidData data3;
        RapidData data4;
        ABB.Robotics.Controllers.RapidDomain.Num _num1;
        ABB.Robotics.Controllers.RapidDomain.Num _num2;
        ABB.Robotics.Controllers.RapidDomain.Num _num3;
        ABB.Robotics.Controllers.RapidDomain.Num _num4;
        double num1;
        double num2;
        double num3;
        double num4;
        public Form1()
        {
            InitializeComponent();
            createcontroler();
            listmethod();
        }

        public void createcontroler()
        {
            this.objNetworkWatcher = new NetworkScanner();
            objNetworkWatcher.Scan();

            ControllerInfoCollection objControllerInfoCollection = objNetworkWatcher.Controllers;
            objController = new Controller(objControllerInfoCollection[0]);
            objController.Logon(UserInfo.DefaultUser);

        }
        public void listmethod()
        {

            data1 = objController.Rapid.GetTask("T_ROB1").GetModule("MainModule").GetRapidData("data");
            data1.ValueChanged += new EventHandler<DataValueChangedEventArgs>(data1_ValueChanged);
            data2 = objController.Rapid.GetTask("T_ROB1").GetModule("Data1").GetRapidData("data12");
            data2.ValueChanged +=new EventHandler<DataValueChangedEventArgs>(data2_ValueChanged);
            data3 = objController.Rapid.GetTask("T_ROB1").GetModule("Data1").GetRapidData("data12");
            data3.ValueChanged +=new EventHandler<DataValueChangedEventArgs>(data3_ValueChanged);
            data4 = objController.Rapid.GetTask("T_ROB1").GetModule("Data1").GetRapidData("data12");
            data4.ValueChanged +=new EventHandler<DataValueChangedEventArgs>(data4_ValueChanged);
            _num1 = (ABB.Robotics.Controllers.RapidDomain.Num)data1.Value;
            num1 = _num1.Value;
            _num2 = (ABB.Robotics.Controllers.RapidDomain.Num)data2.Value;
            num2 = _num2.Value;
            _num3 = (ABB.Robotics.Controllers.RapidDomain.Num)data3.Value;
            num3 = _num3.Value;
            _num4 = (ABB.Robotics.Controllers.RapidDomain.Num)data4.Value;
            num4 = _num4.Value;
            dataGridView1.Rows.Add(data1.Symbol.Scope[0], data1.Symbol.Scope[1], data1.Symbol.Scope[2], num1);
            dataGridView1.Rows.Add(data2.Symbol.Scope[0], data2.Symbol.Scope[1], data2.Symbol.Scope[2], num2);
            dataGridView1.Rows.Add(data3.Symbol.Scope[0], data3.Symbol.Scope[1], data3.Symbol.Scope[2], num3);
            dataGridView1.Rows.Add(data4.Symbol.Scope[0], data4.Symbol.Scope[1], data4.Symbol.Scope[2], num4);
            dataGridView1.AutoGenerateColumns = false;

        }

        void OnRowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {


                this.textBox4.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                this.textBox3.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                this.textBox2.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                this.textBox1.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();

            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void data1_ValueChanged(object sender, DataValueChangedEventArgs e)
        {

            string str = sender.ToString();


        }

        private void data2_ValueChanged(object sender, DataValueChangedEventArgs e)
        {

            string str = sender.ToString();


        }
        private void data3_ValueChanged(object sender, DataValueChangedEventArgs e)
        {

            string str = sender.ToString();


        }
        private void data4_ValueChanged(object sender, DataValueChangedEventArgs e)
        {

            string str = sender.ToString();


        }


    }
}

